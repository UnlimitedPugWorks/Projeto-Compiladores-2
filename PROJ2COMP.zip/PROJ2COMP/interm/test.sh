./minor -trace < test.min
nasm -felf32 out.asm
ld -m elf_i386 out.o libminor.a -o out
./out
